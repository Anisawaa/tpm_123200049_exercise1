package com.example.exercise1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
